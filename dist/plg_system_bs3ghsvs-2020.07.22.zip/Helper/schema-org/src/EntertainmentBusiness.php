<?php

namespace Spatie\SchemaOrg;

/**
 * A business providing entertainment.
 *
 * @see http://schema.org/EntertainmentBusiness
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class EntertainmentBusiness extends BaseType
{
}
