<?php

namespace Spatie\SchemaOrg;

/**
 * An outlet store.
 *
 * @see http://schema.org/OutletStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class OutletStore extends BaseType
{
}
