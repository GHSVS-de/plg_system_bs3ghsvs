<?php

namespace Spatie\SchemaOrg;

/**
 * A motorcycle repair shop.
 *
 * @see http://schema.org/MotorcycleRepair
 *
 * @mixin \Spatie\SchemaOrg\AutomotiveBusiness
 */
class MotorcycleRepair extends BaseType
{
}
