<?php

namespace Spatie\SchemaOrg;

/**
 * A park.
 *
 * @see http://schema.org/Park
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class Park extends BaseType
{
}
