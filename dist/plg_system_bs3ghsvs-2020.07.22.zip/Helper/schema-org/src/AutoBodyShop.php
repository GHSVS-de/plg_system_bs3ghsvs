<?php

namespace Spatie\SchemaOrg;

/**
 * Auto body shop.
 *
 * @see http://schema.org/AutoBodyShop
 *
 * @mixin \Spatie\SchemaOrg\AutomotiveBusiness
 */
class AutoBodyShop extends BaseType
{
}
