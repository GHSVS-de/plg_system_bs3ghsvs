<?php

namespace Spatie\SchemaOrg;

/**
 * An elementary school.
 *
 * @see http://schema.org/ElementarySchool
 *
 * @mixin \Spatie\SchemaOrg\EducationalOrganization
 */
class ElementarySchool extends BaseType
{
}
