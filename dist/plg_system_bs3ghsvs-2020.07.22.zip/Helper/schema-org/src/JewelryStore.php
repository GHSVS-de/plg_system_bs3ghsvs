<?php

namespace Spatie\SchemaOrg;

/**
 * A jewelry store.
 *
 * @see http://schema.org/JewelryStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class JewelryStore extends BaseType
{
}
