<?php

namespace Spatie\SchemaOrg;

/**
 * A library.
 *
 * @see http://schema.org/Library
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class Library extends BaseType
{
}
