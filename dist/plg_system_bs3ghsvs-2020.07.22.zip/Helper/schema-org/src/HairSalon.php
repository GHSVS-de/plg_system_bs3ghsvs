<?php

namespace Spatie\SchemaOrg;

/**
 * A hair salon.
 *
 * @see http://schema.org/HairSalon
 *
 * @mixin \Spatie\SchemaOrg\HealthAndBeautyBusiness
 */
class HairSalon extends BaseType
{
}
