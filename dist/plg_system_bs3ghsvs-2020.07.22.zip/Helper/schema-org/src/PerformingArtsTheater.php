<?php

namespace Spatie\SchemaOrg;

/**
 * A theater or other performing art center.
 *
 * @see http://schema.org/PerformingArtsTheater
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class PerformingArtsTheater extends BaseType
{
}
