<?php

namespace Spatie\SchemaOrg;

/**
 * A Childcare center.
 *
 * @see http://schema.org/ChildCare
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class ChildCare extends BaseType
{
}
