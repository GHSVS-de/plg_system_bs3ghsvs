<?php

namespace Spatie\SchemaOrg;

/**
 * An event venue.
 *
 * @see http://schema.org/EventVenue
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class EventVenue extends BaseType
{
}
