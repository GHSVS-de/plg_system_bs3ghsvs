<?php

namespace Spatie\SchemaOrg;

/**
 * Health and beauty.
 *
 * @see http://schema.org/HealthAndBeautyBusiness
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class HealthAndBeautyBusiness extends BaseType
{
}
