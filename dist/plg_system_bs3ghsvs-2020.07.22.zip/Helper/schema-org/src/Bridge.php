<?php

namespace Spatie\SchemaOrg;

/**
 * A bridge.
 *
 * @see http://schema.org/Bridge
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class Bridge extends BaseType
{
}
