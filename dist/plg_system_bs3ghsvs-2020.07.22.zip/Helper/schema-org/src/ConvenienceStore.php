<?php

namespace Spatie\SchemaOrg;

/**
 * A convenience store.
 *
 * @see http://schema.org/ConvenienceStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class ConvenienceStore extends BaseType
{
}
