<?php

namespace Spatie\SchemaOrg;

/**
 * An adult entertainment establishment.
 *
 * @see http://schema.org/AdultEntertainment
 *
 * @mixin \Spatie\SchemaOrg\EntertainmentBusiness
 */
class AdultEntertainment extends BaseType
{
}
