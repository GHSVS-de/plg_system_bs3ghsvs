<?php

namespace Spatie\SchemaOrg;

/**
 * A playground.
 *
 * @see http://schema.org/Playground
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class Playground extends BaseType
{
}
