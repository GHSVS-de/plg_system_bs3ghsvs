<?php

namespace Spatie\SchemaOrg;

/**
 * A painting.
 *
 * @see http://schema.org/Painting
 *
 * @mixin \Spatie\SchemaOrg\CreativeWork
 */
class Painting extends BaseType
{
}
