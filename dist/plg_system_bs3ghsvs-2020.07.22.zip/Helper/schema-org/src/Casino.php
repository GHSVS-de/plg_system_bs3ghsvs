<?php

namespace Spatie\SchemaOrg;

/**
 * A casino.
 *
 * @see http://schema.org/Casino
 *
 * @mixin \Spatie\SchemaOrg\EntertainmentBusiness
 */
class Casino extends BaseType
{
}
