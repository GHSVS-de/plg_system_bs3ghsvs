<?php

namespace Spatie\SchemaOrg;

/**
 * Beauty salon.
 *
 * @see http://schema.org/BeautySalon
 *
 * @mixin \Spatie\SchemaOrg\HealthAndBeautyBusiness
 */
class BeautySalon extends BaseType
{
}
