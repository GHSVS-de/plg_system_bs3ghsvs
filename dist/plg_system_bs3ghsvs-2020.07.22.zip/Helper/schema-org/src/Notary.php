<?php

namespace Spatie\SchemaOrg;

/**
 * A notary.
 *
 * @see http://schema.org/Notary
 *
 * @mixin \Spatie\SchemaOrg\LegalService
 */
class Notary extends BaseType
{
}
