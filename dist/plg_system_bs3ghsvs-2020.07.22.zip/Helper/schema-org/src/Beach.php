<?php

namespace Spatie\SchemaOrg;

/**
 * Beach.
 *
 * @see http://schema.org/Beach
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class Beach extends BaseType
{
}
