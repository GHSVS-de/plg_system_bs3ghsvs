<?php

namespace Spatie\SchemaOrg;

/**
 * An amusement park.
 *
 * @see http://schema.org/AmusementPark
 *
 * @mixin \Spatie\SchemaOrg\EntertainmentBusiness
 */
class AmusementPark extends BaseType
{
}
