<?php

namespace Spatie\SchemaOrg;

/**
 * A high school.
 *
 * @see http://schema.org/HighSchool
 *
 * @mixin \Spatie\SchemaOrg\EducationalOrganization
 */
class HighSchool extends BaseType
{
}
