<?php

namespace Spatie\SchemaOrg;

/**
 * A Buddhist temple.
 *
 * @see http://schema.org/BuddhistTemple
 *
 * @mixin \Spatie\SchemaOrg\PlaceOfWorship
 */
class BuddhistTemple extends BaseType
{
}
