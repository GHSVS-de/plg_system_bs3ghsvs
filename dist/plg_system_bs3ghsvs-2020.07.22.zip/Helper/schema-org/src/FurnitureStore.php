<?php

namespace Spatie\SchemaOrg;

/**
 * A furniture store.
 *
 * @see http://schema.org/FurnitureStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class FurnitureStore extends BaseType
{
}
