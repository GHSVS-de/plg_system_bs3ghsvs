<?php

namespace Spatie\SchemaOrg;

/**
 * An email message.
 *
 * @see http://schema.org/EmailMessage
 *
 * @mixin \Spatie\SchemaOrg\Message
 */
class EmailMessage extends BaseType
{
}
