<?php

namespace Spatie\SchemaOrg;

/**
 * An internet cafe.
 *
 * @see http://schema.org/InternetCafe
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class InternetCafe extends BaseType
{
}
