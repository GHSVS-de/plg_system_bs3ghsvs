<?php

namespace Spatie\SchemaOrg;

/**
 * A lake (for example, Lake Pontrachain).
 *
 * @see http://schema.org/LakeBodyOfWater
 *
 * @mixin \Spatie\SchemaOrg\BodyOfWater
 */
class LakeBodyOfWater extends BaseType
{
}
