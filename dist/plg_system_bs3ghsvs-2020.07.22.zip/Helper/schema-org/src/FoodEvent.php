<?php

namespace Spatie\SchemaOrg;

/**
 * Event type: Food event.
 *
 * @see http://schema.org/FoodEvent
 *
 * @mixin \Spatie\SchemaOrg\Event
 */
class FoodEvent extends BaseType
{
}
