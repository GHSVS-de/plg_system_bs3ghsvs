<?php

namespace Spatie\SchemaOrg;

/**
 * A dry-cleaning business.
 *
 * @see http://schema.org/DryCleaningOrLaundry
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class DryCleaningOrLaundry extends BaseType
{
}
