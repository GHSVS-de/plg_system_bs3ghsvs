<?php

namespace Spatie\SchemaOrg;

/**
 * An embassy.
 *
 * @see http://schema.org/Embassy
 *
 * @mixin \Spatie\SchemaOrg\GovernmentBuilding
 */
class Embassy extends BaseType
{
}
