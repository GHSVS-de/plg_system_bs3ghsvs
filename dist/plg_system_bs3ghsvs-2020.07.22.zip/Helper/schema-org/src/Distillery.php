<?php

namespace Spatie\SchemaOrg;

/**
 * A distillery.
 *
 * @see http://schema.org/Distillery
 *
 * @mixin \Spatie\SchemaOrg\FoodEstablishment
 */
class Distillery extends BaseType
{
}
