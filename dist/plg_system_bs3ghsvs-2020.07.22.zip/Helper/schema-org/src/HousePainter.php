<?php

namespace Spatie\SchemaOrg;

/**
 * A house painting service.
 *
 * @see http://schema.org/HousePainter
 *
 * @mixin \Spatie\SchemaOrg\HomeAndConstructionBusiness
 */
class HousePainter extends BaseType
{
}
