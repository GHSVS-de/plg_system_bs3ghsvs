<?php

namespace Spatie\SchemaOrg;

/**
 * A doctor's office.
 *
 * @see http://schema.org/Physician
 *
 * @mixin \Spatie\SchemaOrg\MedicalOrganization
 */
class Physician extends BaseType
{
}
