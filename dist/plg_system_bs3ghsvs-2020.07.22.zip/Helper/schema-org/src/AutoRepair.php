<?php

namespace Spatie\SchemaOrg;

/**
 * Car repair business.
 *
 * @see http://schema.org/AutoRepair
 *
 * @mixin \Spatie\SchemaOrg\AutomotiveBusiness
 */
class AutoRepair extends BaseType
{
}
