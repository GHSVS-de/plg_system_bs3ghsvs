<?php

namespace Spatie\SchemaOrg;

/**
 * The act of marrying a person.
 *
 * @see http://schema.org/MarryAction
 *
 * @mixin \Spatie\SchemaOrg\InteractAction
 */
class MarryAction extends BaseType
{
}
