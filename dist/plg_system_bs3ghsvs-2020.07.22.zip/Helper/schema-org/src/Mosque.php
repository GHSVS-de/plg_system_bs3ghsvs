<?php

namespace Spatie\SchemaOrg;

/**
 * A mosque.
 *
 * @see http://schema.org/Mosque
 *
 * @mixin \Spatie\SchemaOrg\PlaceOfWorship
 */
class Mosque extends BaseType
{
}
