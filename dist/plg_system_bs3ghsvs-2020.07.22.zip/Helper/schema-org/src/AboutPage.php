<?php

namespace Spatie\SchemaOrg;

/**
 * Web page type: About page.
 *
 * @see http://schema.org/AboutPage
 *
 * @mixin \Spatie\SchemaOrg\WebPage
 */
class AboutPage extends BaseType
{
}
