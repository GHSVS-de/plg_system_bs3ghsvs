<?php

namespace Spatie\SchemaOrg;

/**
 * Web page type: Image gallery page.
 *
 * @see http://schema.org/ImageGallery
 *
 * @mixin \Spatie\SchemaOrg\CollectionPage
 */
class ImageGallery extends BaseType
{
}
