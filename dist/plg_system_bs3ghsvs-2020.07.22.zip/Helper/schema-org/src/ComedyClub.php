<?php

namespace Spatie\SchemaOrg;

/**
 * A comedy club.
 *
 * @see http://schema.org/ComedyClub
 *
 * @mixin \Spatie\SchemaOrg\EntertainmentBusiness
 */
class ComedyClub extends BaseType
{
}
