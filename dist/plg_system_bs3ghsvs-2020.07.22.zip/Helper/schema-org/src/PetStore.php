<?php

namespace Spatie\SchemaOrg;

/**
 * A pet store.
 *
 * @see http://schema.org/PetStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class PetStore extends BaseType
{
}
