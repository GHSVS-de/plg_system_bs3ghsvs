<?php

namespace Spatie\SchemaOrg;

/**
 * A graveyard.
 *
 * @see http://schema.org/Cemetery
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class Cemetery extends BaseType
{
}
