<?php

namespace Spatie\SchemaOrg;

/**
 * A clothing store.
 *
 * @see http://schema.org/ClothingStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class ClothingStore extends BaseType
{
}
