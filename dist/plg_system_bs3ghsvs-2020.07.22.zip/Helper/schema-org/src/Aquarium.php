<?php

namespace Spatie\SchemaOrg;

/**
 * Aquarium.
 *
 * @see http://schema.org/Aquarium
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class Aquarium extends BaseType
{
}
