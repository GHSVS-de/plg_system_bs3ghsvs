<?php

namespace Spatie\SchemaOrg;

/**
 * A radio station.
 *
 * @see http://schema.org/RadioStation
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class RadioStation extends BaseType
{
}
