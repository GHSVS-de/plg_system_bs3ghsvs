<?php

namespace Spatie\SchemaOrg;

/**
 * An ice cream shop.
 *
 * @see http://schema.org/IceCreamShop
 *
 * @mixin \Spatie\SchemaOrg\FoodEstablishment
 */
class IceCreamShop extends BaseType
{
}
