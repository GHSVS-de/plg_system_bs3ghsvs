<?php

namespace Spatie\SchemaOrg;

/**
 * A computer store.
 *
 * @see http://schema.org/ComputerStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class ComputerStore extends BaseType
{
}
