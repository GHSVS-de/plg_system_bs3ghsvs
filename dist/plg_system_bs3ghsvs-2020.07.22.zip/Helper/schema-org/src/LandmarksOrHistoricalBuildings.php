<?php

namespace Spatie\SchemaOrg;

/**
 * An historical landmark or building.
 *
 * @see http://schema.org/LandmarksOrHistoricalBuildings
 *
 * @mixin \Spatie\SchemaOrg\Place
 */
class LandmarksOrHistoricalBuildings extends BaseType
{
}
