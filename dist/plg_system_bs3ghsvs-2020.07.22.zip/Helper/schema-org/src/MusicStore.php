<?php

namespace Spatie\SchemaOrg;

/**
 * A music store.
 *
 * @see http://schema.org/MusicStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class MusicStore extends BaseType
{
}
