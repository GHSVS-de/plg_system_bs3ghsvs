<?php

namespace Spatie\SchemaOrg;

/**
 * An art gallery.
 *
 * @see http://schema.org/ArtGallery
 *
 * @mixin \Spatie\SchemaOrg\EntertainmentBusiness
 */
class ArtGallery extends BaseType
{
}
