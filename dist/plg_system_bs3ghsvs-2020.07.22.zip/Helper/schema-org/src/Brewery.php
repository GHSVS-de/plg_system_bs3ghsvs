<?php

namespace Spatie\SchemaOrg;

/**
 * Brewery.
 *
 * @see http://schema.org/Brewery
 *
 * @mixin \Spatie\SchemaOrg\FoodEstablishment
 */
class Brewery extends BaseType
{
}
