<?php

namespace Spatie\SchemaOrg;

/**
 * A plumbing service.
 *
 * @see http://schema.org/Plumber
 *
 * @mixin \Spatie\SchemaOrg\HomeAndConstructionBusiness
 */
class Plumber extends BaseType
{
}
