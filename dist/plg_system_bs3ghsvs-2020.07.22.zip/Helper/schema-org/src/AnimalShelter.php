<?php

namespace Spatie\SchemaOrg;

/**
 * Animal shelter.
 *
 * @see http://schema.org/AnimalShelter
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class AnimalShelter extends BaseType
{
}
