<?php

namespace Spatie\SchemaOrg;

/**
 * A music venue.
 *
 * @see http://schema.org/MusicVenue
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class MusicVenue extends BaseType
{
}
