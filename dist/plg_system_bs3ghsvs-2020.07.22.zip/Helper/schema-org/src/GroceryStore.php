<?php

namespace Spatie\SchemaOrg;

/**
 * A grocery store.
 *
 * @see http://schema.org/GroceryStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class GroceryStore extends BaseType
{
}
