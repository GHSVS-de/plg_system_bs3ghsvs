<?php

namespace Spatie\SchemaOrg;

/**
 * An electrician.
 *
 * @see http://schema.org/Electrician
 *
 * @mixin \Spatie\SchemaOrg\HomeAndConstructionBusiness
 */
class Electrician extends BaseType
{
}
