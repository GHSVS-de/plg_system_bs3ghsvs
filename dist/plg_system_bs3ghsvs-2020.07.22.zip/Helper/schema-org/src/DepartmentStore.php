<?php

namespace Spatie\SchemaOrg;

/**
 * A department store.
 *
 * @see http://schema.org/DepartmentStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class DepartmentStore extends BaseType
{
}
