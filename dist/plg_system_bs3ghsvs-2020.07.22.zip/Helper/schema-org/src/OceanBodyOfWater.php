<?php

namespace Spatie\SchemaOrg;

/**
 * An ocean (for example, the Pacific).
 *
 * @see http://schema.org/OceanBodyOfWater
 *
 * @mixin \Spatie\SchemaOrg\BodyOfWater
 */
class OceanBodyOfWater extends BaseType
{
}
