<?php

namespace Spatie\SchemaOrg;

/**
 * Web page type: Collection page.
 *
 * @see http://schema.org/CollectionPage
 *
 * @mixin \Spatie\SchemaOrg\WebPage
 */
class CollectionPage extends BaseType
{
}
