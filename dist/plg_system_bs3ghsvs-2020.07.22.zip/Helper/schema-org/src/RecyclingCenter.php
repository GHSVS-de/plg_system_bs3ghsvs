<?php

namespace Spatie\SchemaOrg;

/**
 * A recycling center.
 *
 * @see http://schema.org/RecyclingCenter
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class RecyclingCenter extends BaseType
{
}
