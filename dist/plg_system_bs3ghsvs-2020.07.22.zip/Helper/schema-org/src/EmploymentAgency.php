<?php

namespace Spatie\SchemaOrg;

/**
 * An employment agency.
 *
 * @see http://schema.org/EmploymentAgency
 *
 * @mixin \Spatie\SchemaOrg\LocalBusiness
 */
class EmploymentAgency extends BaseType
{
}
