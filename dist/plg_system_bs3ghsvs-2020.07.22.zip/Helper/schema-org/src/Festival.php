<?php

namespace Spatie\SchemaOrg;

/**
 * Event type: Festival.
 *
 * @see http://schema.org/Festival
 *
 * @mixin \Spatie\SchemaOrg\Event
 */
class Festival extends BaseType
{
}
