<?php

namespace Spatie\SchemaOrg;

/**
 * A men's clothing store.
 *
 * @see http://schema.org/MensClothingStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class MensClothingStore extends BaseType
{
}
