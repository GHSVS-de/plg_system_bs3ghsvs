<?php

namespace Spatie\SchemaOrg;

/**
 * A motorcycle dealer.
 *
 * @see http://schema.org/MotorcycleDealer
 *
 * @mixin \Spatie\SchemaOrg\AutomotiveBusiness
 */
class MotorcycleDealer extends BaseType
{
}
