<?php

namespace Spatie\SchemaOrg;

/**
 * A hardware store.
 *
 * @see http://schema.org/HardwareStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class HardwareStore extends BaseType
{
}
