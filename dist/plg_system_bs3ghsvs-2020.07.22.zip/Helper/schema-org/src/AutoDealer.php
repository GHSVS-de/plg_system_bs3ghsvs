<?php

namespace Spatie\SchemaOrg;

/**
 * An car dealership.
 *
 * @see http://schema.org/AutoDealer
 *
 * @mixin \Spatie\SchemaOrg\AutomotiveBusiness
 */
class AutoDealer extends BaseType
{
}
