<?php

namespace Spatie\SchemaOrg;

/**
 * A Hindu temple.
 *
 * @see http://schema.org/HinduTemple
 *
 * @mixin \Spatie\SchemaOrg\PlaceOfWorship
 */
class HinduTemple extends BaseType
{
}
