<?php

namespace Spatie\SchemaOrg;

/**
 * Event type: Education event.
 *
 * @see http://schema.org/EducationEvent
 *
 * @mixin \Spatie\SchemaOrg\Event
 */
class EducationEvent extends BaseType
{
}
