<?php

namespace Spatie\SchemaOrg;

/**
 * A crematorium.
 *
 * @see http://schema.org/Crematorium
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class Crematorium extends BaseType
{
}
