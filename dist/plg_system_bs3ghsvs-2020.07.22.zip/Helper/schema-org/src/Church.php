<?php

namespace Spatie\SchemaOrg;

/**
 * A church.
 *
 * @see http://schema.org/Church
 *
 * @mixin \Spatie\SchemaOrg\PlaceOfWorship
 */
class Church extends BaseType
{
}
