<?php

namespace Spatie\SchemaOrg;

/**
 * Residence type: Gated community.
 *
 * @see http://schema.org/GatedResidenceCommunity
 *
 * @mixin \Spatie\SchemaOrg\Residence
 */
class GatedResidenceCommunity extends BaseType
{
}
