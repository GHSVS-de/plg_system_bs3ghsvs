<?php

namespace Spatie\SchemaOrg;

/**
 * A blog post.
 *
 * @see http://schema.org/BlogPosting
 *
 * @mixin \Spatie\SchemaOrg\SocialMediaPosting
 */
class BlogPosting extends BaseType
{
}
