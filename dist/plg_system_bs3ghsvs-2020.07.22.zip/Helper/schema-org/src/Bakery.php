<?php

namespace Spatie\SchemaOrg;

/**
 * A bakery.
 *
 * @see http://schema.org/Bakery
 *
 * @mixin \Spatie\SchemaOrg\FoodEstablishment
 */
class Bakery extends BaseType
{
}
