<?php

namespace Spatie\SchemaOrg;

/**
 * A gas station.
 *
 * @see http://schema.org/GasStation
 *
 * @mixin \Spatie\SchemaOrg\AutomotiveBusiness
 */
class GasStation extends BaseType
{
}
