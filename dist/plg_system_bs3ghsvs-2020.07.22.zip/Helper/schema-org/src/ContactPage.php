<?php

namespace Spatie\SchemaOrg;

/**
 * Web page type: Contact page.
 *
 * @see http://schema.org/ContactPage
 *
 * @mixin \Spatie\SchemaOrg\WebPage
 */
class ContactPage extends BaseType
{
}
