<?php

namespace Spatie\SchemaOrg;

/**
 * A garden store.
 *
 * @see http://schema.org/GardenStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class GardenStore extends BaseType
{
}
