<?php

namespace Spatie\SchemaOrg;

/**
 * An Insurance agency.
 *
 * @see http://schema.org/InsuranceAgency
 *
 * @mixin \Spatie\SchemaOrg\FinancialService
 */
class InsuranceAgency extends BaseType
{
}
