<?php

namespace Spatie\SchemaOrg;

/**
 * A music video file.
 *
 * @see http://schema.org/MusicVideoObject
 *
 * @mixin \Spatie\SchemaOrg\MediaObject
 */
class MusicVideoObject extends BaseType
{
}
