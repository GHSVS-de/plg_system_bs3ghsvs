<?php

namespace Spatie\SchemaOrg;

/**
 * A nail salon.
 *
 * @see http://schema.org/NailSalon
 *
 * @mixin \Spatie\SchemaOrg\HealthAndBeautyBusiness
 */
class NailSalon extends BaseType
{
}
