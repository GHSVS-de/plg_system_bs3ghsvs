<?php

namespace Spatie\SchemaOrg;

/**
 * A bowling alley.
 *
 * @see http://schema.org/BowlingAlley
 *
 * @mixin \Spatie\SchemaOrg\SportsActivityLocation
 */
class BowlingAlley extends BaseType
{
}
