<?php

namespace Spatie\SchemaOrg;

/**
 * A gym.
 *
 * @see http://schema.org/ExerciseGym
 *
 * @mixin \Spatie\SchemaOrg\SportsActivityLocation
 */
class ExerciseGym extends BaseType
{
}
