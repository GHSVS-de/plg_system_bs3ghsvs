<?php

namespace Spatie\SchemaOrg;

/**
 * A car wash business.
 *
 * @see http://schema.org/AutoWash
 *
 * @mixin \Spatie\SchemaOrg\AutomotiveBusiness
 */
class AutoWash extends BaseType
{
}
