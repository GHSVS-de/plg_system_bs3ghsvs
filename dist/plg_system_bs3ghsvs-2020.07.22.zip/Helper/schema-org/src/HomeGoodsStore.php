<?php

namespace Spatie\SchemaOrg;

/**
 * A home goods store.
 *
 * @see http://schema.org/HomeGoodsStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class HomeGoodsStore extends BaseType
{
}
