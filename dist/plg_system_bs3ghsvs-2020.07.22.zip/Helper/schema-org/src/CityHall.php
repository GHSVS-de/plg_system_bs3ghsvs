<?php

namespace Spatie\SchemaOrg;

/**
 * A city hall.
 *
 * @see http://schema.org/CityHall
 *
 * @mixin \Spatie\SchemaOrg\GovernmentBuilding
 */
class CityHall extends BaseType
{
}
