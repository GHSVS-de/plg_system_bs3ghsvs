<?php

namespace Spatie\SchemaOrg;

/**
 * A government building.
 *
 * @see http://schema.org/GovernmentBuilding
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class GovernmentBuilding extends BaseType
{
}
