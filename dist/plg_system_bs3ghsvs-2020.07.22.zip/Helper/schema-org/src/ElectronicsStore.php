<?php

namespace Spatie\SchemaOrg;

/**
 * An electronics store.
 *
 * @see http://schema.org/ElectronicsStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class ElectronicsStore extends BaseType
{
}
