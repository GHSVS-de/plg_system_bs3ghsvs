<?php

namespace Spatie\SchemaOrg;

/**
 * A bus stop.
 *
 * @see http://schema.org/BusStop
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class BusStop extends BaseType
{
}
