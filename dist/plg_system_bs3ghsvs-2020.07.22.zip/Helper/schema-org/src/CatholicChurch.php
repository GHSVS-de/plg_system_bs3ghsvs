<?php

namespace Spatie\SchemaOrg;

/**
 * A Catholic church.
 *
 * @see http://schema.org/CatholicChurch
 *
 * @mixin \Spatie\SchemaOrg\Church
 */
class CatholicChurch extends BaseType
{
}
