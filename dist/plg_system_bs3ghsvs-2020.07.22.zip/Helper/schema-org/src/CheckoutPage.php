<?php

namespace Spatie\SchemaOrg;

/**
 * Web page type: Checkout page.
 *
 * @see http://schema.org/CheckoutPage
 *
 * @mixin \Spatie\SchemaOrg\WebPage
 */
class CheckoutPage extends BaseType
{
}
