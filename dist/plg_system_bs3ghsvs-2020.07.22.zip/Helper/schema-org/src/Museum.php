<?php

namespace Spatie\SchemaOrg;

/**
 * A museum.
 *
 * @see http://schema.org/Museum
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class Museum extends BaseType
{
}
