<?php

namespace Spatie\SchemaOrg;

/**
 * A movie rental store.
 *
 * @see http://schema.org/MovieRentalStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class MovieRentalStore extends BaseType
{
}
