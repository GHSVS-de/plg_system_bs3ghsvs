<?php

namespace Spatie\SchemaOrg;

/**
 * A pond.
 *
 * @see http://schema.org/Pond
 *
 * @mixin \Spatie\SchemaOrg\BodyOfWater
 */
class Pond extends BaseType
{
}
