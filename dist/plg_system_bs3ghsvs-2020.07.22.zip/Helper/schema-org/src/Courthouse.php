<?php

namespace Spatie\SchemaOrg;

/**
 * A courthouse.
 *
 * @see http://schema.org/Courthouse
 *
 * @mixin \Spatie\SchemaOrg\GovernmentBuilding
 */
class Courthouse extends BaseType
{
}
