<?php

namespace Spatie\SchemaOrg;

/**
 * Computer programming source code. Example: Full (compile ready) solutions,
 * code snippet samples, scripts, templates.
 *
 * @see http://schema.org/Code
 *
 * @mixin \Spatie\SchemaOrg\CreativeWork
 */
class Code extends BaseType
{
}
