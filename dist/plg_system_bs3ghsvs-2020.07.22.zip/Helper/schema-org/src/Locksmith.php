<?php

namespace Spatie\SchemaOrg;

/**
 * A locksmith.
 *
 * @see http://schema.org/Locksmith
 *
 * @mixin \Spatie\SchemaOrg\HomeAndConstructionBusiness
 */
class Locksmith extends BaseType
{
}
