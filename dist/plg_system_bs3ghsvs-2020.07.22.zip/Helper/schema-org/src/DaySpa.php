<?php

namespace Spatie\SchemaOrg;

/**
 * A day spa.
 *
 * @see http://schema.org/DaySpa
 *
 * @mixin \Spatie\SchemaOrg\HealthAndBeautyBusiness
 */
class DaySpa extends BaseType
{
}
