<?php

namespace Spatie\SchemaOrg;

/**
 * A bus station.
 *
 * @see http://schema.org/BusStation
 *
 * @mixin \Spatie\SchemaOrg\CivicStructure
 */
class BusStation extends BaseType
{
}
