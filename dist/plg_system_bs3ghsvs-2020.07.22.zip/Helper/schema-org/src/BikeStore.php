<?php

namespace Spatie\SchemaOrg;

/**
 * A bike store.
 *
 * @see http://schema.org/BikeStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class BikeStore extends BaseType
{
}
