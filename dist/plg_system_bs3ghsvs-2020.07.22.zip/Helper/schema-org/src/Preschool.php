<?php

namespace Spatie\SchemaOrg;

/**
 * A preschool.
 *
 * @see http://schema.org/Preschool
 *
 * @mixin \Spatie\SchemaOrg\EducationalOrganization
 */
class Preschool extends BaseType
{
}
