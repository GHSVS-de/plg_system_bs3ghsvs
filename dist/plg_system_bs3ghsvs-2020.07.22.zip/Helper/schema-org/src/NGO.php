<?php

namespace Spatie\SchemaOrg;

/**
 * Organization: Non-governmental Organization.
 *
 * @see http://schema.org/NGO
 *
 * @mixin \Spatie\SchemaOrg\Organization
 */
class NGO extends BaseType
{
}
