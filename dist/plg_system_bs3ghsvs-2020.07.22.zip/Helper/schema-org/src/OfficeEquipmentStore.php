<?php

namespace Spatie\SchemaOrg;

/**
 * An office equipment store.
 *
 * @see http://schema.org/OfficeEquipmentStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class OfficeEquipmentStore extends BaseType
{
}
