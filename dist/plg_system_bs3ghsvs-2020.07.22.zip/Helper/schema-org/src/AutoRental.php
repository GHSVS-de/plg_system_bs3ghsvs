<?php

namespace Spatie\SchemaOrg;

/**
 * A car rental business.
 *
 * @see http://schema.org/AutoRental
 *
 * @mixin \Spatie\SchemaOrg\AutomotiveBusiness
 */
class AutoRental extends BaseType
{
}
