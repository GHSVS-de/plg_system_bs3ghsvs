<?php

namespace Spatie\SchemaOrg;

/**
 * A bookstore.
 *
 * @see http://schema.org/BookStore
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class BookStore extends BaseType
{
}
