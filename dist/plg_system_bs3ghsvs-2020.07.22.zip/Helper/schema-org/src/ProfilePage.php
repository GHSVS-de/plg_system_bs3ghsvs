<?php

namespace Spatie\SchemaOrg;

/**
 * Web page type: Profile page.
 *
 * @see http://schema.org/ProfilePage
 *
 * @mixin \Spatie\SchemaOrg\WebPage
 */
class ProfilePage extends BaseType
{
}
