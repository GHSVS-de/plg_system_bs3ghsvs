<?php

namespace Spatie\SchemaOrg;

/**
 * A golf course.
 *
 * @see http://schema.org/GolfCourse
 *
 * @mixin \Spatie\SchemaOrg\SportsActivityLocation
 */
class GolfCourse extends BaseType
{
}
