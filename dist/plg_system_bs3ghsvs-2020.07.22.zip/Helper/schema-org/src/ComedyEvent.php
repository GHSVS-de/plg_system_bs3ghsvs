<?php

namespace Spatie\SchemaOrg;

/**
 * Event type: Comedy event.
 *
 * @see http://schema.org/ComedyEvent
 *
 * @mixin \Spatie\SchemaOrg\Event
 */
class ComedyEvent extends BaseType
{
}
