<?php

namespace Spatie\SchemaOrg;

/**
 * Event type: Business event.
 *
 * @see http://schema.org/BusinessEvent
 *
 * @mixin \Spatie\SchemaOrg\Event
 */
class BusinessEvent extends BaseType
{
}
