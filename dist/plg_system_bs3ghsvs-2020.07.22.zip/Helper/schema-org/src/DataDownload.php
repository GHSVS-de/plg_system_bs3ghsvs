<?php

namespace Spatie\SchemaOrg;

/**
 * A dataset in downloadable form.
 *
 * @see http://schema.org/DataDownload
 *
 * @mixin \Spatie\SchemaOrg\MediaObject
 */
class DataDownload extends BaseType
{
}
