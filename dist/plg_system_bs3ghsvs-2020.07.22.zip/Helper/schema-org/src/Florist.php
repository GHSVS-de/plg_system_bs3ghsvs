<?php

namespace Spatie\SchemaOrg;

/**
 * A florist.
 *
 * @see http://schema.org/Florist
 *
 * @mixin \Spatie\SchemaOrg\Store
 */
class Florist extends BaseType
{
}
