<?php

namespace Spatie\SchemaOrg;

/**
 * A post office.
 *
 * @see http://schema.org/PostOffice
 *
 * @mixin \Spatie\SchemaOrg\GovernmentOffice
 */
class PostOffice extends BaseType
{
}
