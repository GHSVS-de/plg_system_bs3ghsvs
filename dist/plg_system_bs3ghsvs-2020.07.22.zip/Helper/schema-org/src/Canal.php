<?php

namespace Spatie\SchemaOrg;

/**
 * A canal, like the Panama Canal.
 *
 * @see http://schema.org/Canal
 *
 * @mixin \Spatie\SchemaOrg\BodyOfWater
 */
class Canal extends BaseType
{
}
