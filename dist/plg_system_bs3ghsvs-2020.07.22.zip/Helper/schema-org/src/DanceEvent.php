<?php

namespace Spatie\SchemaOrg;

/**
 * Event type: A social dance.
 *
 * @see http://schema.org/DanceEvent
 *
 * @mixin \Spatie\SchemaOrg\Event
 */
class DanceEvent extends BaseType
{
}
